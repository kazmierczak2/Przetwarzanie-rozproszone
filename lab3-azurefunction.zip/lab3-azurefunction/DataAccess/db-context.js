const sql = require('mssql');
const parser = require('mssql-connection-string');

class PeopleDbContext {
    constructor(connectionString, log) {
        log("PeopleDbContext object has been created.");
        this.log = log;
        this.config = parser(connectionString);
        this.getPeople = this.getPeople.bind(this);
    }

    async getPeople() {
        this.log("getPeople function - run")
        const connection = await new sql.ConnectionPool(this.config).connect();
        const request = new sql.Request(connection);
        const result = await request.query('select * from People');
        this.log("getPeople function - done")
        return result.recordset;
    }

    async getPerson(){
        this.log("getPeople function - run")
        const connection = await new sql.ConnectionPool(this.config).connect();
        const request = new sql.Request(connection);
        const result = await request.query('select * from People where PersonId  = 1');
        this.log("getPeople function - done")
        return result.recordset;
    }

    async addPerson(req, res){
        const connection = await new sql.ConnectionPool(this.config).connect();
        const request = new sql.Request(connection);

        
        const FirstName = req.body.FirstName;
        const LastName = req.body.LastName;
        const PhoneNumber = req.body.PhoneNumber;
        
        const result = await request.query('Insert into People values ( '+ FirstName + ', '+ LastName+', '+PhoneNumber+');');
    }
}

module.exports = PeopleDbContext;